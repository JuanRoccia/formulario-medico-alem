# config.py
BITGET_API_KEY = 'your_api_key'
BITGET_SECRET_KEY = 'your_secret_key'
BITGET_PASSPHRASE = 'your_passphrase'